from flask import Flask, render_template,request
import json
from werkzeug.utils import secure_filename
import os, glob
import requests,re
import xml.etree.ElementTree as ET
from scrapy.selector import Selector
from ObjectDetector import Detector
from flask import send_from_directory
import camelot
from pandas import  ExcelWriter
import xlsxwriter
import pdfkit
import pandas as pd
import boto3
import botocore
import pdftotext
import re
import configparser

app = Flask(__name__)
UPLOAD_FOLDER = './static/UploadFiles'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
detector = Detector()
config = configparser.ConfigParser()
config.read_file(open(r'./app_config.txt'))
bucket_name = config.get('your-config', 'bucket_name')
key = config.get('your-config', 'key')
aws_secret_key= config.get('your-config', 'aws_secret_key')
aws_secret_key_id= config.get('your-config', 'aws_secret_key_id')

@app.route('/')
def index():
   return render_template('file_upload.html')

@app.route('/view-pdf', methods = ['GET', 'POST'])
def upload_file():
    #http://10.8.4.187:5000/upload?pdf_doc_id=1387495&page_num=10
    pdf_doc_id = request.args.get('pdf_doc_id')
    page_num = request.args.get('page_num')
    sentence=request.args.get('sentence')[:20]
    print(sentence)
    sentiment=request.args.get('sentiment')
    show_full_pdf=int(request.args.get('show_full_pdf'))
    if request.method == 'GET':
        BUCKET_NAME = bucket_name # replace with your bucket name
        KEY = key+str(pdf_doc_id)+'.pdf' # replace with your object key
        s3 = boto3.resource('s3',
                           aws_access_key_id=aws_secret_key_id,
                          aws_secret_access_key=aws_secret_key)
        try:
            s3.Bucket(BUCKET_NAME).download_file(KEY, os.path.join(app.config['UPLOAD_FOLDER'], str(pdf_doc_id)+".pdf"))
        except botocore.exceptions.ClientError as e:
            if e.response['Error']['Code'] == "404":
                print("The object does not exist.")
            else:
                raise
    worker_js_path = './static/js/pdf.worker.js'
    if show_full_pdf==1:
        return render_template('viewer.html',file_path='./static/UploadFiles/{0}'.format(str(pdf_doc_id)+'.pdf'),worker_js = worker_js_path,sentence=sentence,sentiment=sentiment,show_full_pdf=show_full_pdf)
    else:
        sentence1=request.args.get('sentence')
        sentiment_obj = {'positive':'#b6eeb6','negative':'red','neutral':'yellow'}
        with open('./static/UploadFiles/{0}'.format(str(pdf_doc_id)+'.pdf'),"rb") as f:
            pdf=pdftotext.PDF(f)
        pagenumber=''
        flag=False
        for i in range(0,len(pdf)):
            if re.search(sentence,str(pdf[i]).replace('\n','')):
                print(i)
                string=str(pdf[i]).replace('\n','').split(sentence)
                string1=string[0].split()[-50:-1]
                string1=' '.join(string1)
                string2=string[1].split()[1:100]
                string2=' '.join(string2)
                pagenumber=i
                flag=True
            else:
                pass
        if flag==True:
            return render_template('show_full_pdf_0.html',string1=string1,string2=string2,sentence_matching=sentence1,sentiment=sentiment_obj[sentiment],page_numer=pagenumber)
        else:
            return render_template('error.html')

@app.route('/points',methods = ['GET', 'POST'])
def get_intresting_points():
    obj = dict(request.args)
    print(obj)
    points = json.loads(obj['points'])
    b=json.loads(obj['total_number_of_pages'])
    #page_num = obj['page_number']
    file_path = obj['file_path']
    print(points)
    print(file_path)
    # if points:
    print ("Selection Found")
    page_num = obj['page_number']
    img_r,imgfname,img = detector.detectObject(file_path,int(page_num))
    print(imgfname)
    pdf_page=detector.norm_pdf_page(file_path,int(page_num))
    z = detector.detect_table(imgfname)
    interesting_areas=[]
    for x in z:
        [x1, y1, x2, y2] = detector.bboxes_pdf(img, pdf_page, x)
        bbox_camelot = [",".join([str(x1), str(y1), str(x2), str(y2)])][0]
        print(bbox_camelot)
        interesting_areas.append(bbox_camelot)
    if len(interesting_areas)>=1:
        output_camelot = camelot.read_pdf(filepath=file_path, pages=str(page_num), table_areas=interesting_areas,flavor='stream',strip_text='\n\t')
        output_camelot=[x.df for x in output_camelot]
        file_name_to_download=file_path[:-4]+'_'+str(page_num)+'.xlsx'
        print(file_name_to_download)
        print("Saving the file as :",file_name_to_download)
        start_row = 1
        with ExcelWriter(file_path[:-4]+'_'+str(page_num)+'.xlsx',engine='xlsxwriter',mode='w') as writer:
            for i,db in enumerate(output_camelot):
                db.to_excel(writer,sheet_name=str(i+1),)
                #start_row += len(db) + 1 
            writer.save()
        print("File Saved")
        print(file_name_to_download.replace(UPLOAD_FOLDER,''))
        return '{0}'.format(file_name_to_download)
    else:
        output_camelot = camelot.read_pdf(filepath=file_path, pages=str(page_num),flavor='stream',strip_text='\n\t')
        output_camelot=[x.df for x in output_camelot]
        file_name_to_download=file_path[:-4]+'_'+str(page_num)+'.xlsx'
        print(file_name_to_download)
        print("Saving the file as :",file_name_to_download)
        start_row = 1
        with ExcelWriter(file_path[:-4]+'_'+str(page_num)+'.xlsx',engine='xlsxwriter',mode='w') as writer:
            for i,db in enumerate(output_camelot):
                db.to_excel(writer,sheet_name=str(i+1),)
                #start_row += len(db) + 1 
            writer.save()
        print("File Saved")
        print(file_name_to_download.replace(UPLOAD_FOLDER,''))
        return '{0}'.format(file_name_to_download)
            # print('No table DETECTED')
            # file_name_to_download=file_path[:-4]+'_'+str(page_num)+'.xlsx'
            # writer = pd.ExcelWriter(file_path[:-4]+'_'+str(page_num)+'.xlsx', engine='xlsxwriter')
            # workbook  = writer.book
            # ws = workbook.add_worksheet('mytab')

            # ws.write(1,1,'No Tables Detected // Corrupted pdf file')
            # writer.save()
            # writer.close()
            # print("File Saved")
            # print(file_name_to_download.replace(UPLOAD_FOLDER,''))
            # return '{0}'.format(file_name_to_download)


    # else:
    #     print ("Selection Not Found")
    #     try:
    #         v=[]
    #         for i in range(b):
    #             print(i)
    #             file1=i+1
    #             output_camelot = camelot.read_pdf(filepath=file_path, pages=str(file1), flavor='stream',strip_text='\n\t')
    #             output_camelot=[x.df for x in output_camelot]
    #             if len(output_camelot)>=1:
    #                 v.append(output_camelot)
    #             else:
    #                 print('*****Passing*****')
    #         file_name_to_download=file_path[:-4]+'.xlsx'
    #         print(file_name_to_download)
    #         print("Saving the file as :",file_name_to_download)
    #         start_row = 1
    #         print(len(v))
    #         with ExcelWriter(file_path[:-4]+'.xlsx', engine='xlsxwriter') as writer:
    #             for k,h in enumerate(v,(len(v)*10)):
    #                 for j,g in enumerate(h,len(h)):
    #                     g.to_excel(writer,sheet_name=str(k)+str(j))
    #         print("File Saved")

    #         return '{0}'.format(file_name_to_download)

    #     except:
    #         print('No table DETECTED')
    #         writer = pd.ExcelWriter(file[:-4]+'.xlsx', engine='xlsxwriter')
    #         workbook  = writer.book
    #         ws = workbook.add_worksheet('mytab')

    #         ws.write(1,1,'No Tables Detected // Corrupted pdf file')
    #         writer.save()
    #         writer.close()
    #         print("File Saved")
    #         return '{0}'.format(file_name_to_download)


# for f in os.listdir(app.config['UPLOAD_FOLDER']):
#     try:
#         os.remove(app.config['UPLOAD_FOLDER']+'/'+f)
#     except:
#         pass

if __name__ == '__main__':
   app.run(host='10.8.4.187',port='5000',debug=True)
   #app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
