[your-config]

bucket_name='####'
key='####'
aws_secret_key='####'
aws_secret_key_id='#####'

