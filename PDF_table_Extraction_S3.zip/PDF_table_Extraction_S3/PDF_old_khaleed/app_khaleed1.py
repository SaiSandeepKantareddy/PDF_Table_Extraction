from flask import Flask, render_template,request
import json
from werkzeug.utils import secure_filename
import os, glob
import requests,re
import xml.etree.ElementTree as ET
from scrapy.selector import Selector
from ObjectDetector import Detector
from flask import send_from_directory
import camelot
from pandas import  ExcelWriter
import xlsxwriter
import pdfkit
import pandas as pd
import boto3
import botocore


app = Flask(__name__)
UPLOAD_FOLDER = './static/UploadFiles'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
detector = Detector()


@app.route('/')
def index():
   return render_template('file_upload.html')

@app.route('/view-pdf', methods = ['GET', 'POST'])
def upload_file():
    #http://10.8.4.187:5000/upload?pdf_doc_id=1387495&page_num=10
    pdf_doc_id = request.args.get('pdf_doc_id')
    page_num = request.args.get('page_num')
    if request.method == 'GET':
        BUCKET_NAME = '####' # replace with your bucket name
        KEY = '####'+str(pdf_doc_id)+'.pdf' # replace with your object key
        #output=os.path.join(app.config['UPLOAD_FOLDER'], str(pdf_doc_id)+'.pdf')
        s3 = boto3.resource('s3',
                           aws_access_key_id='####',
                          aws_secret_access_key='####')
        try:
            s3.Bucket(BUCKET_NAME).download_file(KEY, os.path.join(app.config['UPLOAD_FOLDER'], str(pdf_doc_id)+'.pdf'))
        except botocore.exceptions.ClientError as e:
            if e.response['Error']['Code'] == "404":
                print("The object does not exist.")
            else:
                raise
    worker_js_path = './static/js/pdf.worker.js'
    return render_template('viewer.html',file_path='./static/UploadFiles/{0}'.format(str(pdf_doc_id)+'.pdf'),worker_js = worker_js_path)


@app.route('/points',methods = ['GET', 'POST'])
def get_intresting_points():
    obj = dict(request.args)
    print(obj)
    points = json.loads(obj['points'])
    b=json.loads(obj['total_number_of_pages'])
    #page_num = obj['page_number']
    file_path = obj['file_path']
    print(points)
    print(file_path)
    file_name_to_download=file_path[:-4]+'.xlsx'
    if points:
        print ("Selection Found")
        page_num = obj['page_number']
        output_camelot = camelot.read_pdf(filepath=file_path, pages=str(page_num),flavor='stream',strip_text='\n\t')
        output_camelot=[x.df for x in output_camelot]
        file_name_to_download=file_path[:-4]+'.xlsx'
        print(file_name_to_download)
        print("Saving the file as :",file_name_to_download)
        start_row = 1
        with ExcelWriter(file_path[:-4]+'.xlsx',engine='xlsxwriter',mode='w') as writer:
            for i,db in enumerate(output_camelot):
                db.to_excel(writer,sheet_name=str(i+1),)
                #start_row += len(db) + 1 
            writer.save()

        print("File Saved")
        print(file_name_to_download.replace(UPLOAD_FOLDER,''))
        return '{0}'.format(file_name_to_download)
    else:
        print ("Selection Not Found")
        try:
            v=[]
            for i in range(b):
                print(i)
                file1=i+1
                output_camelot = camelot.read_pdf(filepath=file_path, pages=str(file1), flavor='stream',strip_text='\n\t')
                output_camelot=[x.df for x in output_camelot]
                if len(output_camelot)>=1:
                    v.append(output_camelot)
                else:
                    print('*****Passing*****')
            file_name_to_download=file_path[:-4]+'.xlsx'
            print(file_name_to_download)
            print("Saving the file as :",file_name_to_download)
            start_row = 1
            print(len(v))
            with ExcelWriter(file_path[:-4]+'.xlsx', engine='xlsxwriter') as writer:
                for k,h in enumerate(v,(len(v)*10)):
                    for j,g in enumerate(h,len(h)):
                        g.to_excel(writer,sheet_name=str(k)+str(j))
            print("File Saved")

            return '{0}'.format(file_name_to_download)

        except:
            print('No table DETECTED')
            writer = pd.ExcelWriter(file[:-4]+'.xlsx', engine='xlsxwriter')
            workbook  = writer.book
            ws = workbook.add_worksheet('mytab')

            ws.write(1,1,'No Tables Detected // Corrupted pdf file')
            writer.save()
            writer.close()
            print("File Saved")
            return '{0}'.format(file_name_to_download)
    return '{0}'.format(file_name_to_download)

# for f in os.listdir(app.config['UPLOAD_FOLDER']):
#     try:
#         os.remove(app.config['UPLOAD_FOLDER']+'/'+f)
#     except:
#         pass

if __name__ == '__main__':
   app.run(debug = True)
   #app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
